<!--first-->
<a href="" class="pagination-item"><<</a>
<!--first-->
<!--back-->
<a href="" class="pagination-item"><</a>
<!--back-->
<!--previous-->
<a href="" class="pagination-item">1</a>
<!--previous-->
<!--current-->
<a href="" class="pagination-item pagination-item__active">1</a>
<!--current-->
<!--next-->
<a href="" class="pagination-item">1</a>
<!--next-->
<!--forward-->
<a href="" class="pagination-item">></a>
<!--forward-->
<!--last-->
<a href="" class="pagination-item">>></a>
<!--last-->