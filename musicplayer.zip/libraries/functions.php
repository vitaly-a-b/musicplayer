<?php

function print_arr($arr){
    echo '<pre>';
    print_r($arr);
    echo '</pre>';
}