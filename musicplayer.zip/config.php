<?php

defined('VG_ACCESS') or die('Access denied');

//define('DEVELOPMENT_MODE', true);

const SITE_URL = 'https://musicplayer/';

const PATH = '/';

const HOST = 'localhost';
const USER = 'musicplayer';
const PASS = 'Veronika2018';
const DB_NAME = 'music';

