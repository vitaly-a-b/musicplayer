<?php

namespace core\base\exceptions;

class CacheException extends \Exception
{

}