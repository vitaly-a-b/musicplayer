<?php
/**
 * Created by PhpStorm.
 * User: developer
 * Date: 12.03.2019
 * Time: 14:51
 */

namespace core\base\exceptions;


class LowLevelException extends \Exception
{

}