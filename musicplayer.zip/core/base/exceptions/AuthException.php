<?php
/**
 * Created by PhpStorm.
 * User: developer
 * Date: 12.03.2019
 * Time: 18:07
 */

namespace core\base\exceptions;

use core\base\controller\BaseMethods;
use core\base\settings\Settings;

class AuthException extends \Exception
{



}