<?php


namespace core\base\model;


use core\base\controller\Singleton;

class DBStorage
{

    use Singleton;


}