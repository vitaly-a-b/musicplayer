<?=$this->header?>
<?=$this->content?>
<?=$this->footer?>
