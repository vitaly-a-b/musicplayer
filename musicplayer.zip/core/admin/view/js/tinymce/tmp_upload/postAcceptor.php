<?php

$_SESSION['files'] = $_FILES['file'];
