<!--FIRST-->
<li class="wq-pagination__item wq-pagination__arrow">
    <a href="#" class="wq-pagination__icon _ibg">
        <picture>
            <source srcset="<?=PATH . ADMIN_TEMPLATE?>img/icons/icon-arrow-prev.webp" type="image/webp">
            <img src="<?=PATH . ADMIN_TEMPLATE?>img/icons/icon-arrow-prev.png" alt="icon">
        </picture>
    </a>
</li>
<!--FIRST-->
<!--PREVIOUS-->
<li class="wq-pagination__item">
    <a href="##" class="wq-pagination__link">1</a>
</li>
<!--PREVIOUS-->
<!--CURRENT-->
<li class="wq-pagination__item">
    <a href="##" class="wq-pagination__link _active">3</a>
</li>
<!--CURRENT-->
<!--NEXT-->
<li class="wq-pagination__item">
    <a href="##" class="wq-pagination__link">4</a>
</li>
<!--NEXT-->
<!--LAST-->
<li class="wq-pagination__item wq-pagination__arrow">
    <a href="#" class="wq-pagination__icon _ibg">
        <picture>
            <source srcset="<?=PATH . ADMIN_TEMPLATE?>img/icons/icon-arrow-next.webp" type="image/webp">
            <img src="<?=PATH . ADMIN_TEMPLATE?>img/icons/icon-arrow-next.png" alt="icon">
        </picture>
    </a>
</li>
<!--LAST-->